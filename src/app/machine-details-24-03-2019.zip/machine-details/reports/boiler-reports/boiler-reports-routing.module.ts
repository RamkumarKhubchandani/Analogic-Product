import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {BoilerReportsComponent} from "./boiler-reports.component";

const routes: Routes = [{
  path: "",
  component: BoilerReportsComponent
  
}];





@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class BoilerReportsRoutingModule { }
