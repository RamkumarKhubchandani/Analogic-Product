import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import {CoolingTowerReportsComponent} from "./cooling-tower-reports.component"

const routes: Routes = [{
  path: "",
  component: CoolingTowerReportsComponent
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CoolingTowerReportsRoutingModule { }
