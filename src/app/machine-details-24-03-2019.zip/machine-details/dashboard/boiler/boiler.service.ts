import { Injectable } from '@angular/core';
import { RestApi } from '../../../core/services/rest.service';
import { GlobalErrorHandler } from '../../../core/services/error-handler';


@Injectable()
export class BoilerService {

  constructor(private rest : RestApi) { }
  getMonitor(machineId:string) {
    return  this.rest.get(`utility/utilityMonitoringDashboard/${machineId}`);
    
  }
  getColumn(machineId:string) {
    return  this.rest.get(`utility/utilityColumns/${machineId}`);
  
  }
  getSummary(machineId:string) {
    return  this.rest.get(`utility/utilitySummaryDashboard/${machineId}`);
  
  }
  getName(machineId:number){
    return this.rest.get(`config/associativename/${machineId}`);

  }
  

}
