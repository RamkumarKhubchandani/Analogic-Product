import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-boiler',
  templateUrl: './boiler.component.html',
  styleUrls: ['./boiler.component.scss']
})
export class BoilerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
