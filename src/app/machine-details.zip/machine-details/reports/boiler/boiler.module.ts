import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { BoilerRoutingModule } from './boiler-routing.module';

@NgModule({
  imports: [
    CommonModule,
    BoilerRoutingModule
  ],
  declarations: []
})
export class BoilerModule { }
