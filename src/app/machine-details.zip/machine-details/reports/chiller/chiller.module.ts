import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ChillerRoutingModule } from './chiller-routing.module';

@NgModule({
  imports: [
    CommonModule,
    ChillerRoutingModule
  ],
  declarations: []
})
export class ChillerModule { }
