import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chiller',
  templateUrl: './chiller.component.html',
  styleUrls: ['./chiller.component.scss']
})
export class ChillerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
