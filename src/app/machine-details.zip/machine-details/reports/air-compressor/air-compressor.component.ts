import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-air-compressor',
  templateUrl: './air-compressor.component.html',
  styleUrls: ['./air-compressor.component.scss']
})
export class AirCompressorComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
