import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {AirCompressorComponent} from "./air-compressor.component"

const routes: Routes = [

  {
    path: "",
    component: AirCompressorComponent
    
  }
  
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AirCompressorRoutingModule { }
