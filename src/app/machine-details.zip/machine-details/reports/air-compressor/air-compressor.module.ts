import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import {AirCompressorComponent} from "./air-compressor.component"

import { AirCompressorRoutingModule } from './air-compressor-routing.module';
import { SharedModule } from "../../../shared/modules/shared.module";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import {ReportFormComponent} from "./../../../reports/report-form/report-form.component"
import { OwlDateTimeModule, OwlNativeDateTimeModule } from "ng-pick-datetime";

import { ReportsService } from "./../../../reports/reports.service";

import {ConfigurationService} from '../../../configuration/configuration.service';

@NgModule({
  imports: [
    CommonModule,
    AirCompressorRoutingModule,
    SharedModule,
    FormsModule,
    ReactiveFormsModule,
    OwlDateTimeModule,
    OwlNativeDateTimeModule
  ],
  declarations: [AirCompressorComponent,ReportFormComponent],
  providers: [ReportsService,ConfigurationService]
})
export class AirCompressorModule { }

