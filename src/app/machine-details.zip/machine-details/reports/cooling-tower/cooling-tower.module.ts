import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CoolingTowerRoutingModule } from './cooling-tower-routing.module';

@NgModule({
  imports: [
    CommonModule,
    CoolingTowerRoutingModule
  ],
  declarations: []
})
export class CoolingTowerModule { }
