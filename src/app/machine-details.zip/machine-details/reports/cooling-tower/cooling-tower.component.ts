import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cooling-tower',
  templateUrl: './cooling-tower.component.html',
  styleUrls: ['./cooling-tower.component.scss']
})
export class CoolingTowerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
