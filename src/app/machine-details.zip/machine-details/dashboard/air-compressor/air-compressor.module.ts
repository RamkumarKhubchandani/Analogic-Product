import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from "../../../shared/modules/shared.module";
import {AirCompressorRoutingRoutingModule} from "./air-compressor.routing.module"
import {AirCompressorComponent} from "./air-compressor.component"
 
@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    AirCompressorRoutingRoutingModule
  ],
  declarations: [AirCompressorComponent]
})
export class AirCompressorModule { }
