import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-air-compressor',
  templateUrl: './air-compressor.component.html',
  styleUrls: ['./air-compressor.component.scss']
})
export class AirCompressorComponent implements OnInit {
  airData = {
    "total_energy_consumed" : "1418.0",
    "specific_power_consumption" : "23.70243248",
    "total_air_compressed" : "647.0"
  }
  constructor() { }

  ngOnInit() {
  }

}
