import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cooling-tower',
  templateUrl: './cooling-tower.component.html',
  styleUrls: ['./cooling-tower.component.scss']
})
export class CoolingTowerComponent implements OnInit {
  airData = {
    "total_energy_consumed" : "1418.0",
    "specific_power_consumption" : "23.70243248",
    "total_air_compressed" : "647.0"
  }
  constructor() { }

  ngOnInit() {
  }

}
