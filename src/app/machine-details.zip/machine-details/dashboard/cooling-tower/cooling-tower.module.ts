import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import {CoolingTowerRoutingModule} from "./cooling-tower.routing.module"
import { SharedModule } from "../../../shared/modules/shared.module";

import { CoolingTowerComponent } from "./cooling-tower.component"

@NgModule({
  imports: [
    CommonModule,
    CoolingTowerRoutingModule,
    SharedModule
  ],
  declarations: [CoolingTowerComponent]
})
export class CoolingTowerModule { }
