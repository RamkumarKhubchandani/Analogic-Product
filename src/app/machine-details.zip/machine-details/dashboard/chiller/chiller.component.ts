import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chiller',
  templateUrl: './chiller.component.html',
  styleUrls: ['./chiller.component.scss']
})
export class ChillerComponent implements OnInit {
  airData = {
    "total_energy_consumed" : "1418.0",
    "specific_power_consumption" : "23.70243248",
    "total_air_compressed" : "647.0"
  }
  
  constructor() { }

  ngOnInit() {
  }

}
