import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {ChillerRoutingModule} from "./chiller.routing.module"
import { SharedModule } from "../../../shared/modules/shared.module";
import { ChillerComponent } from "./chiller.component"

@NgModule({
  imports: [
    CommonModule,
    ChillerRoutingModule,
    SharedModule
  ],
  declarations: [ChillerComponent]
})
export class ChillerModule { }
