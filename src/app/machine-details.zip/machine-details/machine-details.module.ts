import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CoreModule } from "../core/core.module";
import {MachineDetailsRoutingModule} from "./machine-details.routing.module"
import { SharedModule } from "../shared/modules/shared.module";
import {MachineDetailsComponent} from "./machine-details.component";
// import { MachineCategoryComponent } from './machine-category/machine-category.component';
// import {MachineCategoryModule} from './machine-category/machine-category.module'
import { PipesModule } from "../shared/pipes/pipe.module";
import {MachineService} from "../machine/machine.service";
@NgModule({
  imports: [
    CommonModule, 
    CoreModule,
    MachineDetailsRoutingModule,
    SharedModule,
    PipesModule
     
    
  ],
  declarations: [MachineDetailsComponent],
  providers: [MachineService]
  // exports: [
  //   MachineCategoryComponent
  // ]
})
export class MachineDetailsModule { }
