import { Component, OnInit ,Input} from '@angular/core';

@Component({
  selector: 'app-machine-category',
  templateUrl: './machine-category.component.html',
  styleUrls: ['./machine-category.component.scss']
})

export class MachineCategoryComponent implements OnInit {
  @Input() machinename: string;
  mname = "Air Compressor";
  m_params=["KW consumption","Air flow in CFM","compressed air volume","specific power consumption"]

  constructor() { }

  ngOnInit() {
    
  }

}
