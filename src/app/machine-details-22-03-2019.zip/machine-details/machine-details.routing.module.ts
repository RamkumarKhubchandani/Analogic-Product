import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";

import { MachineDetailsComponent } from "./machine-details.component";



const machinedetailRoutes: Routes = [
  {
    path: "",
    component: MachineDetailsComponent,
    children : [
        {
            path : "aircompressor",
            loadChildren : "./dashboard/air-compressor/air-compressor.module#AirCompressorModule"
        },
        {
            path : "boiler",
            loadChildren : "./dashboard/boiler/boiler.module#BoilerModule"
        },
        {
            path : "chiller",
            loadChildren : "./dashboard/chiller/chiller.module#ChillerModule"
        },
        {
            path : "coolingtower",
            loadChildren : "./dashboard/cooling-tower/cooling-tower.module#CoolingTowerModule"
        },
        {
          path : "aircompressorreport",
          loadChildren : "./reports/air-compressor-reports/air-compressor-reports.module#AirCompressorReportsModule"
        },
        // {
        //   path : "coolingtowerreport",
        //   loadChildren : "./reports/cooling-tower/cooling-tower.module#CoolingTowerModule"
        // }
    ]
  }
  
 
];
@NgModule({
  imports: [RouterModule.forChild(machinedetailRoutes)],
  exports: [RouterModule]
})
export class MachineDetailsRoutingModule {}
