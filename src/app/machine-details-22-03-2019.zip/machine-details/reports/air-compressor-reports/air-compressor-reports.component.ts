import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-air-compressor-reports',
  templateUrl: './air-compressor-reports.component.html',
  styleUrls: ['./air-compressor-reports.component.scss']
})
export class AirCompressorReportsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
